(function() {
  'use strict';

  const API_PATTERNS = [
    { method: 'POST', pattern: '/api/vendor/products', event_type: 'listing_created' },
    { method: 'GET', pattern: '/api/vendor/products/', event_type: 'product_created' },
    { method: 'PUT', pattern: '/api/vendor/products/', event_type: 'product_updated' },
    { method: 'POST', pattern: '/api/quality-check/products/', suffix: '/approve', event_type: 'qc_approved' },
    { method: 'POST', pattern: '/api/quality-check/products/', suffix: '/reject', event_type: 'qc_rejected' },
    { method: 'GET', pattern: '/api/quality-check/products', requiredParams: ['qcStatus=pending'], event_type: 'qc_pending', extractPagination: true }
  ];

  function matchPattern(method, url) {
    const matches = [];
    for (const apiPattern of API_PATTERNS) {
      if (method !== apiPattern.method) continue;
      if (!url.includes(apiPattern.pattern)) continue;
      if (apiPattern.suffix && !url.includes(apiPattern.suffix)) continue;
      if (apiPattern.requiredParams) {
        const hasAll = apiPattern.requiredParams.every(p => url.includes(p));
        if (!hasAll) continue;
      }
      matches.push(apiPattern);
    }
    return matches;
  }

  function hasData(val) {
    return val && typeof val === 'object' && Object.keys(val).length > 0;
  }

  function hasPackageTypeObject(val) {
    if (!val || typeof val !== 'object') return false;
    if (Array.isArray(val)) return false;
    return Object.values(val).some(v => v != null && v !== '');
  }

  function detectEventType(matched, reqBody, responseData, method) {
    if (matched.event_type === 'product_created') {
      const data = responseData?.data || responseData;
      const productId = data?._id || data?.id;
      const hasPackageType = data?.packageType && (
        (typeof data.packageType === 'string' && data.packageType.length > 0) ||
        (typeof data.packageType === 'object' && !Array.isArray(data.packageType))
      );
      if (productId && !hasPackageType) {
        return 'product_created';
      }
      return null;
    }
    if (matched.event_type === 'product_updated') {
      if (hasData(responseData?.categoryComplianceDetails)) {
        return 'spec_added';
      }
      if (hasPackageTypeObject(reqBody?.packageType) && (responseData?.packageTypeID || (typeof responseData?.packageType === 'string' && responseData.packageType))) {
        return 'listing_created';
      }
      return 'product_updated';
    }
    // POST to /api/vendor/products = always listing_created
    if (matched.event_type === 'listing_created' && method === 'POST') {
      return 'listing_created';
    }
    return matched.event_type;
  }

  function extractData(responseData, eventType) {
    if (eventType === 'qc_pending') {
      const pendingCount = responseData?.pagination?.total ?? null;
      return {
        product_id: null, vendor_id: null, product_name: null,
        qc_status: 'pending', is_qc_approved: false, product_sku: null,
        event_type: eventType, pending_count: pendingCount,
        timestamp: new Date().toISOString()
      };
    }

    const data = responseData?.data || responseData;
    return {
      product_id: data._id || data.id || null,
      vendor_id: typeof data.vendor === 'object' ? data.vendor?._id : data.vendor || null,
      product_name: data.productName || null,
      qc_status: data.qcStatus || null,
      is_qc_approved: data.isQCApproved || false,
      product_sku: data.productSku || null,
      event_type: eventType,
      timestamp: new Date().toISOString()
    };
  }

  function sendEvent(eventType, data) {
    console.log('[BD Tracker] Sending event to bridge:', eventType);
    window.postMessage({
      type: 'BD_TRACKER_INTERCEPTED',
      event_type: eventType,
      data: data
    }, '*');
  }

  console.log('[BD Tracker] Content script loaded');

  const _nativeFetch = window.fetch;

  window.fetch = async function(...args) {
    const reqObj = args[0];
    const url = typeof reqObj === 'string' ? reqObj : reqObj?.url || '';
    const method = (args[1]?.method || reqObj?.method || 'GET').toUpperCase();

    // Get request body
    let reqBody = null;
    if (args[1]?.body) {
      try {
        reqBody = typeof args[1].body === 'string' ? JSON.parse(args[1].body) : args[1].body;
      } catch (e) {}
    }
    // If a Request object was passed, clone it to read body (clone gets independent stream)
    if (!reqBody && reqObj?.clone && (method === 'POST' || method === 'PUT')) {
      try {
        const clonedReq = reqObj.clone();
        const bodyText = await clonedReq.text();
        if (bodyText) reqBody = JSON.parse(bodyText);
      } catch (e) {}
    }

    try {
      const matches = matchPattern(method, url);
      if (matches.length > 0) {
        console.log('[BD Tracker] Fetch intercepted:', method, url);
        const response = await _nativeFetch.apply(this, args);
        const clone = response.clone();
        let responseData = {};
        try { responseData = await clone.json(); } catch(e) {}

        for (const matched of matches) {
          let eventType = detectEventType(matched, reqBody, responseData, method);
          if (!eventType) {
            console.log('[BD Tracker] Skipped — no valid event type');
            continue;
          }
          console.log('[BD Tracker] Detected event type:', eventType, 'reqBody.packageType:', reqBody?.packageType, 'responseData.packageType:', responseData?.packageType);
          const data = extractData(responseData, eventType);
          data.url = url.split('?')[0];
          data.method = method;
          sendEvent(eventType, data);
        }
        return response;
      }
    } catch (err) {
      console.error('[BD Tracker] Fetch intercept error:', err);
    }

    return _nativeFetch.apply(this, args);
  };

  const _nativeOpen = XMLHttpRequest.prototype.open;
  const _nativeSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._bdMethod = method;
    this._bdUrl = url;
    return _nativeOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(body) {
    const method = (this._bdMethod || 'GET').toUpperCase();
    const url = this._bdUrl || '';

    let reqBody = null;
    if ((method === 'PUT' || method === 'POST') && body) {
      try {
        reqBody = typeof body === 'string' ? JSON.parse(body) : body;
      } catch (e) {}
    }

    this.addEventListener('load', function() {
      try {
        const matches = matchPattern(method, url);
        if (matches.length > 0) {
          console.log('[BD Tracker] XHR intercepted:', method, url);
          let responseData = {};
          try { responseData = JSON.parse(this.responseText); } catch(e) {}

          for (const matched of matches) {
            let eventType = detectEventType(matched, reqBody, responseData, method);
            if (!eventType) continue;
            const data = extractData(responseData, eventType);
            data.url = url.split('?')[0];
            data.method = method;
            sendEvent(eventType, data);
          }
        }
      } catch (err) {}
    });
    return _nativeSend.apply(this, [body]);
  };
})();
