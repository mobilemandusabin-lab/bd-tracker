// BD Tracker — Content Script
// Intercepts API calls on commerce.thecanbrand.com

(function() {
  'use strict';

  const API_PATTERNS = [
    { method: 'POST', pattern: '/api/vendor/products', event_type: 'listing_created' },
    { method: 'PUT', pattern: '/api/vendor/products/', event_type: 'product_updated' },
    { method: 'POST', pattern: '/api/quality-check/products/', suffix: '/approve', event_type: 'qc_approved' },
    { method: 'POST', pattern: '/api/quality-check/products/', suffix: '/reject', event_type: 'qc_rejected' }
  ];

  function matchPattern(method, url) {
    for (const apiPattern of API_PATTERNS) {
      if (method !== apiPattern.method) continue;
      if (!url.includes(apiPattern.pattern)) continue;
      if (apiPattern.suffix && !url.includes(apiPattern.suffix)) continue;
      return apiPattern;
    }
    return null;
  }

  function extractData(responseData, eventType) {
    const data = responseData?.data || responseData;
    return {
      product_id: data._id || data.id || null,
      vendor_id: data.vendor || null,
      product_name: data.productName || null,
      qc_status: data.qcStatus || null,
      is_qc_approved: data.isQCApproved || false,
      product_sku: data.productSku || null,
      event_type: eventType,
      timestamp: new Date().toISOString()
    };
  }

  // Intercept fetch calls
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);

    try {
      const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
      const method = (args[1]?.method || 'GET').toUpperCase();

      const matched = matchPattern(method, url);
      if (matched) {
        const clonedResponse = response.clone();
        let responseData;
        try {
          responseData = await clonedResponse.json();
        } catch (e) {
          responseData = {};
        }

        chrome.runtime.sendMessage({
          type: 'BD_TRACKER_EVENT',
          event_type: matched.event_type,
          data: extractData(responseData, matched.event_type)
        }).catch(() => {});
      }
    } catch (err) {
      // Silently fail — don't break the page
    }

    return response;
  };

  // Also intercept XMLHttpRequest for legacy calls
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._bdTrackerMethod = method;
    this._bdTrackerUrl = url;
    return originalXHROpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(body) {
    this.addEventListener('load', function() {
      try {
        const method = (this._bdTrackerMethod || 'GET').toUpperCase();
        const url = this._bdTrackerUrl || '';

        const matched = matchPattern(method, url);
        if (matched) {
          let responseData;
          try {
            responseData = JSON.parse(this.responseText);
          } catch (e) {
            responseData = {};
          }

          chrome.runtime.sendMessage({
            type: 'BD_TRACKER_EVENT',
            event_type: matched.event_type,
            data: extractData(responseData, matched.event_type)
          }).catch(() => {});
        }
      } catch (err) {
        // Silently fail
      }
    });

    return originalXHRSend.apply(this, [body]);
  };
})();
