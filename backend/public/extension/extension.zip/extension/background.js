// BD Tracker — Background Service Worker
importScripts('config.js');

let authToken = null;
let deviceId = null;
let heartbeatTimer = null;
let versionCheckTimer = null;

// Initialize on install
chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(['authToken', 'deviceId', 'userName']);
  authToken = stored.authToken || null;
  deviceId = stored.deviceId || generateDeviceId();

  if (!stored.deviceId) {
    await chrome.storage.local.set({ deviceId });
  }

  if (authToken) {
    startHeartbeat();
    registerDevice();
    checkForUpdates();
  }
});

// Initialize on startup
chrome.runtime.onStartup.addListener(async () => {
  const stored = await chrome.storage.local.get(['authToken', 'deviceId']);
  authToken = stored.authToken || null;
  deviceId = stored.deviceId || generateDeviceId();

  if (authToken) {
    startHeartbeat();
    registerDevice();
    checkForUpdates();
  }
});

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'BD_TRACKER_EVENT') {
    handleEvent(message);
    return;
  }

  if (message.type === 'LOGIN') {
    handleLogin(message).then(sendResponse);
    return true; // async response
  }

  if (message.type === 'LOGOUT') {
    handleLogout().then(sendResponse);
    return true;
  }

  if (message.type === 'GET_STATUS') {
    getStatus().then(sendResponse);
    return true;
  }

  if (message.type === 'SYNC_NOW') {
    syncNow().then(sendResponse);
    return true;
  }
});

// Handle API events from content script
async function handleEvent(message) {
  if (!authToken) return;

  try {
    const response = await fetch(`${CONFIG.API_BASE_URL}/extension/activity-log`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        event_type: message.event_type,
        product_id: message.data.product_id,
        vendor_id: message.data.vendor_id,
        product_name: message.data.product_name,
        qc_status: message.data.qc_status,
        metadata: message.data
      })
    });

    if (!response.ok) {
      const data = await response.json();
      if (response.status === 401) {
        await handleLogout();
      }
    }
  } catch (err) {
    // Network error — will retry on next event
  }
}

// Handle login
async function handleLogin(message) {
  try {
    const response = await fetch(`${CONFIG.API_BASE_URL}/extension/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: message.email, password: message.password })
    });

    const data = await response.json();

    if (response.ok && data.token) {
      authToken = data.token;
      await chrome.storage.local.set({
        authToken: data.token,
        userName: data.data?.user?.name || message.email,
        userEmail: data.data?.user?.email || message.email,
        userTeam: data.data?.user?.team || null
      });

      startHeartbeat();
      registerDevice();
      checkForUpdates();

      return { success: true, userName: data.data?.user?.name || message.email, team: data.data?.user?.team };
    } else {
      return { success: false, message: data.message || 'Login failed' };
    }
  } catch (err) {
    return { success: false, message: 'Network error — is BD Tracker running?' };
  }
}

// Handle logout
async function handleLogout() {
  authToken = null;
  stopHeartbeat();
  await chrome.storage.local.remove(['authToken', 'userName', 'userEmail']);
  return { success: true };
}

// Get current status
async function getStatus() {
  const stored = await chrome.storage.local.get(['authToken', 'userName', 'userEmail', 'deviceId', 'lastSync']);
  return {
    isLoggedIn: !!stored.authToken,
    userName: stored.userName || null,
    userEmail: stored.userEmail || null,
    deviceId: stored.deviceId || null,
    lastSync: stored.lastSync || null,
    version: chrome.runtime.getManifest().version
  };
}

// Register device with backend
async function registerDevice() {
  if (!authToken || !deviceId) return;

  try {
    await fetch(`${CONFIG.API_BASE_URL}/extension/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        device_id: deviceId,
        extension_version: chrome.runtime.getManifest().version
      })
    });
  } catch (err) {
    // Will retry on next heartbeat
  }
}

// Send heartbeat
async function sendHeartbeat() {
  if (!authToken || !deviceId) return;

  try {
    const response = await fetch(`${CONFIG.API_BASE_URL}/extension/heartbeat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({ device_id: deviceId })
    });

    if (response.ok) {
      await chrome.storage.local.set({ lastSync: new Date().toISOString() });
    } else if (response.status === 401) {
      await handleLogout();
    }
  } catch (err) {
    // Network error
  }
}

// Check for extension updates
async function checkForUpdates() {
  try {
    const response = await fetch(`${CONFIG.API_BASE_URL}/extension/latest-version`);
    const data = await response.json();

    if (response.ok && data.data) {
      const currentVersion = chrome.runtime.getManifest().version;
      const latestVersion = data.data.version;

      if (latestVersion !== currentVersion) {
        await chrome.storage.local.set({
          updateAvailable: true,
          latestVersion: latestVersion,
          changelog: data.data.changelog || ''
        });
      } else {
        await chrome.storage.local.set({ updateAvailable: false });
      }
    }
  } catch (err) {
    // Network error
  }
}

// Start heartbeat timer
function startHeartbeat() {
  stopHeartbeat();
  sendHeartbeat();
  heartbeatTimer = setInterval(sendHeartbeat, CONFIG.HEARTBEAT_INTERVAL);

  // Version check
  checkForUpdates();
  versionCheckTimer = setInterval(checkForUpdates, CONFIG.VERSION_CHECK_INTERVAL);
}

// Stop heartbeat timer
function stopHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  if (versionCheckTimer) {
    clearInterval(versionCheckTimer);
    versionCheckTimer = null;
  }
}

// Manual sync
async function syncNow() {
  await sendHeartbeat();
  await checkForUpdates();
  const stored = await chrome.storage.local.get(['lastSync']);
  return { success: true, lastSync: stored.lastSync };
}

// Generate unique device ID
function generateDeviceId() {
  return 'ext_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 9);
}
